### SVCVIZ
<img src="notebooks/SVC-VIZ.png" />

A simple tool for visualizing SVC model coefficient surfaces with very few lines of code enhancing reproducibility and replicability in SVC models. 
